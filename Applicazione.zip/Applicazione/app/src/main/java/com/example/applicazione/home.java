package com.example.applicazione;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;


public class home extends AppCompatActivity {

    Button preferiti, lista;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        prodotti.setChiamante(1);
        preferiti = (Button) findViewById(R.id.Lista_Desideri);
        lista = (Button) findViewById(R.id.Lista_Elementi);

        //indirizza l'utente nella lista desideri
        preferiti.setOnClickListener(view -> {
            Intent intent = new Intent(home.this, desideri.class);
            startActivity(intent);
        });

        //idirizza l'utente nella lista dei prodotti
        lista.setOnClickListener(view -> {
            Intent intent = new Intent(home.this, prodotti.class);
            startActivity(intent);
        });
    }


}