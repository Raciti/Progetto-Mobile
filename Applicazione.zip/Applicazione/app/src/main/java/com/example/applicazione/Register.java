package com.example.applicazione;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class Register extends AppCompatActivity {
    //Gli attributi seguenti si riferiscono all'activity register
    EditText e_mail, Password;
    Button submit;
    TextView login;
    //db è la variabile utilizzata per accedere a firebase
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    // user identifica l'oggetto User, classe creata per la gestione degli utenti
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("Dentro Activity");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        //Di seguito si ottengono gli elementi dell'activity tramite l'id
        e_mail = findViewById(R.id.username2);
        Password = findViewById(R.id.Password2);
        submit = findViewById(R.id.submit_btn);
        login = findViewById(R.id.Already_link);

        //Alla pressione del bottone Submit viene eseguito il seguente codice
        submit.setOnClickListener(view -> {
            //System.out.println("OnClick");
            //Si ottengono gli elementi inseriti dall'utente nelle editText email e password
            String email = e_mail.getText().toString();
            String password = Password.getText().toString();

            // controllo sull'email, se essa è nulla la get produce un'eccezione
            if (email.length() != 0) {
                //nella collezione Users si cerca l'utente tramite l'email
                DocumentReference docRef = db.collection("Users").document(email);
                docRef.get().addOnCompleteListener(task -> {
                    //se l'utente esiste la variabile flag viene posta a true
                    boolean flag;
                    flag = true;
                    //si controllano l'email e la password per vedere se sono accetabili
                    if (!controlloCredenziali(email, password)) {
                        //se non lo sono viene segnalato un errore all'utente
                        Context context = getApplicationContext();
                        CharSequence text = "Errore nell'email o password";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                        flag = false;
                    }
                    //se la task esiste e flag è true l'utente già esiste, viene reindirizzato al login
                    if (task.isSuccessful() && flag) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Context context = getApplicationContext();
                            CharSequence text = "Account Già Esistente";
                            int duration = Toast.LENGTH_SHORT;
                            Toast toast = Toast.makeText(context, text, duration);
                            toast.show();
                        } else {
                            //se non esiste si crea L'utente e lo si inserisce su firebase
                            user = new User(email, password, null);

                            db.collection("Users").document(email)
                                    .set(user)
                                    .addOnSuccessListener(aVoid -> System.out.println("ok"))
                                    .addOnFailureListener(e -> System.out.println("ok"));
                            //Una volta creato e inserito su firebase, l'utente viene reindirizzato all'home
                            Intent intent = new Intent(Register.this, home.class);
                            startActivity(intent);
                        }
                    } else {
                        //controllo per il non funzionamento di firebase
                        System.out.println("SIAMO PERSI");
                    }
                });
            } else {
                Context context = getApplicationContext();
                CharSequence text = "Inserire almeno l'email";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        });

        //alla pressione di login l'utente viene reindirizzato nell'activity login
        login.setOnClickListener(view -> {
            Intent intent = new Intent(Register.this, login.class);
            startActivity(intent);
        });
    }

    //funzione utilizzata per la verifica delle credenziali
    //sono verifiche "semplici", si potrebbero integrare controlli più ferrei
    boolean controlloCredenziali(@NonNull String email, String psw){
        //il campo email deve contenere @, mentre la pssword non dev'essere una stringa vuota
        if((email.indexOf('@') == -1) || (psw.length() == 0)) {
            return false;
        }
        else {
            return true;
        }
    }
}