package com.example.applicazione;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class utenti extends AppCompatActivity {

    FirebaseFirestore db = FirebaseFirestore.getInstance();
    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_utenti);

        List<User> lista = new LinkedList<>();

        back = (Button) findViewById(R.id.btnBackU);
        back.setOnClickListener( view -> {
            Intent intent = new Intent(utenti.this, AdminHome.class);
            startActivity(intent);
            finish();
        });

        scaricoUtenti(lista);
    }

    public void scaricoUtenti(List<User> list){
        //si scaricano le informazioni di tutti gli utenti presenti nel database
        db.collection("Users")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            HashMap<String, Object> info = (HashMap<String, Object>) document.getData();
                            String email = (String)info.get("email");
                            String psw =  (String)info.get("password");
                            User user = new User(email,psw, null);
                            list.add(user);
                        }
                        setAdapter(list);
                    } else {
                        System.out.println("Error getting documents: " + task.getException());
                    }
                });
    }

    public void setAdapter(List<User> list){
        ListView listView = (ListView)findViewById(R.id.item_listU);
        CustomAdapterUtenti adapter = new CustomAdapterUtenti(this, R.layout.activity_righe_utente, list);
        listView.setAdapter(adapter);
    }
}