package com.example.applicazione;

import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class User {
    private static List<Items> preferiti;
    public static String email;
    public String Emails;
    public String password;
    static FirebaseFirestore db = FirebaseFirestore.getInstance();
    static DocumentReference user;

    //costruttore di User
    public User(String email, String password, ArrayList<String> Preferiti){
        //vi sono due attributi email, uno statico e uno dinamico
        // poichè quello dinamico vinee utilizzato da altre app
        this.email = email;
        this.Emails = email;
        this.password = password;
        preferiti = new ArrayList<>();
        if (Preferiti != null){
            for (String nome : Preferiti) {
                //Si strapolano i nomi dei prodotti preferiti dall'utente e si crea la lista preferitti
                // con gli item
                DocumentReference docRef = db.collection("Prodotti").document(nome);
                docRef.get().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Items item =  new Items((String)document.get("nome"), (String)document.get("descrizione"),(String)document.get("prezzo"), String.valueOf(document.get("valutazione")),(String) document.get("path"));
                            preferiti.add(item);
                        }
                    } else {
                        System.out.println("SIAMO PERSI PRODOTTI");
                    }
                });
            }

        }
    }


    public String getEmail() {
        return Emails;
    }

    public String getPassword() {
        return password;
    }


    //utilzzato per aggiungere un item alla lista desideri locale e nel cloud
    @RequiresApi(api = Build.VERSION_CODES.N)
    public static void addPreferito(Items item){
        printPreferenze();
        if (preferiti.indexOf(item) == -1) {
            preferiti.add(item);
            
            user = db.collection("Users").document(email);
            user.update("Preferiti", FieldValue.arrayUnion(item.getNome()));
        } else {
            System.out.println("Non si aggiunge l'elemnto, già è nella lista preferiti");
        }
    }

    //utilzzato per rimuovere un item dalla lista desideri locale e del cloud
    @RequiresApi(api = Build.VERSION_CODES.N)
    public static void removePreferito(Items item){

        for (int i = 0; i < preferiti.size(); i++){
            if(preferiti.get(i).getNome().equals(item.getNome())){
                preferiti.remove(i);
            }
        }
        user = db.collection("Users").document(email);
        user.update("Preferiti", FieldValue.arrayRemove(item.getNome()));
    }

    //Utilizzata per stampare la lista desideri
    @RequiresApi(api = Build.VERSION_CODES.N)
    public static void printPreferenze(){
        if(preferiti.isEmpty() == false) {
            preferiti.forEach(value -> System.out.println(value.Nome));
        } else{
           //System.out.println("Array vuoto");
        }
    }

    public static List<Items> getPreferiti() {
        return preferiti;
    }


}
