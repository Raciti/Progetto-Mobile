package com.example.applicazione;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class login extends AppCompatActivity {

    EditText e_mail, pwd;
    Button login;
    TextView back;
    //attributo utilizzato come flag per l'admin
    static boolean admin;
    User utente;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        admin = false;
        setContentView(R.layout.activity_login);
        e_mail = (EditText)findViewById(R.id.userName);
        pwd = (EditText)findViewById(R.id.pwd);
        login = (Button) findViewById(R.id.login_btn);
        back = (TextView)findViewById(R.id.registerLink);

        login.setOnClickListener(view -> {
            System.out.println("OnClick");
            String email = e_mail.getText().toString();
            String password = pwd.getText().toString();

            //Si controlla se l'utente che effettua il login è un admin
            DocumentReference docAd = db.collection("Admin").document(email);
            docAd.get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        //Se è un admin la variabile admin viene posta a true
                        admin = true;
                        //L'admin viene reindirizzato nella schermata per il super user
                        Intent intent = new Intent(login.this, AdminHome.class);
                        startActivity(intent);
                    } else{
                        //Se l'utente non è un admin lo si cerca tra gli utenti registrati
                        DocumentReference docRef = db.collection("Users").document(email);
                        docRef.get().addOnCompleteListener(task1 -> {
                            if (task1.isSuccessful() && !admin) {
                                DocumentSnapshot document1 = task1.getResult();
                                if (document1.exists()) {
                                    //Si effettua il controllo per vedere se l'utente è registrato
                                    // se esso è registrato viene creato un utente con le sue informazioni caricate da firebase
                                    // e viene reindirizzato nella schermata principale
                                    utente = new User(email, password, (ArrayList<String>) document1.get("Preferiti"));
                                    Intent intent = new Intent(login.this, home.class);
                                    startActivity(intent);
                                } else if(!admin){
                                    //L'utente non è registrato, viene fornito un messaggio e lo si reindirizza alla schermata register
                                    Context context = getApplicationContext();
                                    CharSequence text = "Non esiste l'account, torna alla Registrazione";
                                    int duration = Toast.LENGTH_SHORT;
                                    Toast toast = Toast.makeText(context, text, duration);
                                    toast.show();
                                }
                            } else {
                                System.out.println("SIAMO PERSI");
                            }
                        });
                    }
                } else {
                    System.out.println("SIAMO PERSI");
                }
            });


        });

        //Per tornare nella schermata di registrazione
        back.setOnClickListener(view -> finish());
    }

    //funzione che ritorna il valore di admin
    public static boolean getAdmin(){return admin;}

    //funzione che setta a false admin, utilizzata per quando l'admin slogga
    public static void quitAdmin(){admin = false;}
}