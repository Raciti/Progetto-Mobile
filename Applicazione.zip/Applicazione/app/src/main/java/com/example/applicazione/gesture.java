package com.example.applicazione;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class gesture extends AppCompatActivity {
    Button add, remove, back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gesture);


        add = findViewById(R.id.nuovoProdotto);
        remove =  findViewById(R.id.cancellazioneProdotto);
        back = findViewById(R.id.backG);

        // Cambi di activity
        add.setOnClickListener(view -> {
            Intent intent = new Intent(gesture.this, gesture_addProdotto.class);
            startActivity(intent);
            finish();
        });

        remove.setOnClickListener(view -> {
            Intent intent = new Intent(gesture.this, gesture_deleteProdotto.class);
            startActivity(intent);
            finish();
        });

        // Cliccando il bottone back termina l'attività, ritornando quindi all'activity chiamante AdminHome
        back.setOnClickListener(view -> {
            Intent intent = new Intent(gesture.this, AdminHome.class);
            startActivity(intent);
            finish();
        });

    }
}