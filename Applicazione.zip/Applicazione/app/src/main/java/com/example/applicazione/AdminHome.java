package com.example.applicazione;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminHome extends AppCompatActivity {

    Button logout, Prodotti, utenti, gesture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        prodotti.setChiamante(0);
        logout = (Button) findViewById(R.id.Logout_admin);
        Prodotti = (Button) findViewById(R.id.Lista_Prodotti);
        utenti = (Button) findViewById(R.id.Lista_Utenti);
        gesture = (Button) findViewById(R.id.Gesture);

        logout.setOnClickListener(view -> {
            // richiamando questa funzione settiamo una variabile nell'activity login
            // in questo modo nella schermata di login potranno effettuare l'accesso sia un nuovo/lo stesso admin
            // oppure un user normale
            login.quitAdmin();
            finish();
        });


        //Nel codice successivo si gestiscono i cambi di activity
        // si faccia caso che l'unico tasto che effettua la finish dell'activity è logout
        // in questo modo l'activity Adminhome rimmarà la principale per le azioni successive
        Prodotti.setOnClickListener(view -> {
            Intent intent = new Intent(AdminHome.this, prodotti.class);
            startActivity(intent);
            finish();
        });

        utenti.setOnClickListener(view -> {
            Intent intent = new Intent(AdminHome.this, utenti.class);
            startActivity(intent);
            finish();
        });

        gesture.setOnClickListener(view -> {
            Intent intent = new Intent(AdminHome.this, gesture.class);
            startActivity(intent);
            finish();
        });
    }

}