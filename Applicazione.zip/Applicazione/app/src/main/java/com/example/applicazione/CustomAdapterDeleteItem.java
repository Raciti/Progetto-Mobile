
package com.example.applicazione;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.List;

class CustomAdapterDeleteItem extends ArrayAdapter<Items> {



    public CustomAdapterDeleteItem(Context context, int textViewResourceId, List<Items> objects) {
        super(context, textViewResourceId, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.activity_righe_lista_delete, null);
        TextView nome = (TextView)convertView.findViewById(R.id.Nome_itemD);
        TextView descrizione = (TextView)convertView.findViewById(R.id.Descrizione_itemD);
        TextView prezzo = (TextView)convertView.findViewById(R.id.Prezzo_itemD);
        RatingBar valutazione = (RatingBar) convertView.findViewById(R.id.Valutazione_itemD);
        ImageView image = (ImageView) convertView.findViewById(R.id.Image_itemD);
        ImageButton delete = convertView.findViewById(R.id.delete);

        // In questo modo si prendono gli attributi specifici dell'elemento contenuto nella lista objects
        // si utilizzano i metodi della classe Items
        Items i = getItem(position);
        nome.setText(i.getNome());
        descrizione.setText(i.getDescrizione());
        prezzo.setText(i.getPrezzo() + "€");
        valutazione.setRating(i.getValutazione());

        //Si prende la reference di fire base per poter acceddere a STORAGE
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        // Si ottiene il nome specifico dell'immagine del prodotto caricata nello storage
        StorageReference photoReference= storageReference.child(i.getPath().substring(1));

        final long ONE_MEGABYTE = 1024 * 1024;
        //  Si fissa l'immagine tramite il metodo delle bitmap di FireBase
        photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(bytes -> {
            Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            image.setImageBitmap(bmp);

        }).addOnFailureListener(exception -> System.out.println("Foto non ritrovate"));


        // Si effettua la cancellazione dell'item alla pressione del tasto delete
        // Cancellando l'oggetto dalla collezione cloud
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        delete.setOnClickListener(view -> {
            System.out.println("Cancellazione prodotto:" + i.getNome());
            db.collection("Prodotti").document(i.getNome())
                    .delete()
                    .addOnSuccessListener(aVoid -> System.out.println("Cancellazione effettuata"))
                    .addOnFailureListener(e -> System.out.println("Cancellazione fallita"));
        });

        return convertView;
    }

}
