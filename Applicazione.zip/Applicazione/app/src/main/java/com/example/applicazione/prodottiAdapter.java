package com.example.applicazione;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.List;

class CustomAdapterProdotti extends ArrayAdapter<Items> {

    private List<Items> preferiti;

    public CustomAdapterProdotti(Context context, int textViewResourceId, List<Items> objects) {
        super(context, textViewResourceId, objects);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        preferiti = User.getPreferiti();
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.activity_righe_lista, null);
        TextView nome = (TextView)convertView.findViewById(R.id.Nome_item);
        TextView descrizione = (TextView)convertView.findViewById(R.id.Descrizione_item);
        TextView prezzo = (TextView)convertView.findViewById(R.id.Prezzo_item);
        RatingBar valutazione = (RatingBar) convertView.findViewById(R.id.Valutazione_item);
        Switch cuore = (Switch) convertView.findViewById(R.id.delete);
        ImageView image = (ImageView) convertView.findViewById(R.id.Image_item);

        // In questo modo si prendono gli attributi specifici dell'elemento contenuto nella lista objects
        // si utilizzano i metodi della classe Items
        Items i = getItem(position);
        nome.setText(i.getNome());
        descrizione.setText(i.getDescrizione());
        prezzo.setText(i.getPrezzo() + "€");
        valutazione.setRating(i.getValutazione());

        //Si prende la reference di fire base per poter acceddere a STORAGE
        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        // Si ottiene il nome specifico dell'immagine del prodotto caricata nello storage
        StorageReference photoReference= storageReference.child(i.getPath().substring(1));

        //Metodo di firebase per poter scaricare l'immagine dallo storage
        final long ONE_MEGABYTE = 1024 * 1024;
        photoReference.getBytes(ONE_MEGABYTE).addOnSuccessListener(bytes -> {
            Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            image.setImageBitmap(bmp);

        }).addOnFailureListener(exception -> System.out.println("Foto non ritrovate"));

        //Si imposta lo switch a true se l'utente nella sua lista desideri salvata nel server ha il prodotto salvato
        for (Items item : preferiti) {
            if (item.getNome().equals(i.getNome())) {
                cuore.setChecked(true);
            }
        }

        //Se lo switch cambia di stato l'item viene aggiunto o rimosso dalla lista preferiti
        cuore.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked){
                User.addPreferito(i);
            }else{
                User.removePreferito(i);
            }
        });

        return convertView;
    }

}
