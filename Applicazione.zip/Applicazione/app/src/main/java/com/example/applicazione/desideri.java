package com.example.applicazione;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

public class desideri extends AppCompatActivity {

    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desideri);

        back = findViewById(R.id.btnBack1);
        back.setOnClickListener(view -> finish());

        //Adapeter personalizzato per la vista dinamica di una lista
        setAdapter(User.getPreferiti());


    }

    public void setAdapter(List<Items> list){
        ListView listView = findViewById(R.id.item_list1);
        // list è la lsita dei prodotti preferiti dall'utente, ottenuta tramite il metodo statico "getPreferiti()"
        CustomAdapterPreferiti adapter = new CustomAdapterPreferiti(this, R.layout.activity_righe_lista, list);
        listView.setAdapter(adapter);
    }
}