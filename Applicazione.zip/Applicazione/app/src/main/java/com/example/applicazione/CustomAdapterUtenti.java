package com.example.applicazione;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class CustomAdapterUtenti extends ArrayAdapter<User> {

    public CustomAdapterUtenti(Context context, int textViewResourceId, List<User> users) {
        super(context, textViewResourceId, users);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.activity_righe_utente, null);
        TextView email = convertView.findViewById(R.id.email_utente);
        TextView password = convertView.findViewById(R.id.password_utente);

        //Si settano le informazioni degli utenti risalendo agli user della lista users
        // si utilizzano i metodi della classe utente per estrapolare le informazioni
        User u = getItem(position);
        email.setText(u.getEmail());
        password.setText(u.getPassword());
        return convertView;
    }
}
