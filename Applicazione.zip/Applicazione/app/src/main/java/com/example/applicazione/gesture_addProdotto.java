package com.example.applicazione;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.Objects;
import java.util.UUID;

public class gesture_addProdotto extends AppCompatActivity {

    TextInputEditText nome, prezzo, descrizione, valutazione;
    Button select, upload;
    Button back;
    ImageView imageView;
    FirebaseStorage storage;
    StorageReference storageReference;
    Uri filePath;
    final int PICK_IMAGE_REQUEST = 22;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gesture_add_prodotto);
        nome = findViewById(R.id.textInputEditText_nome);
        descrizione = findViewById(R.id.textInputEditText_descrizione);
        prezzo = findViewById(R.id.textInputEditText_prezzo);
        valutazione = findViewById(R.id.textInputEditText_valutazione);
        back = findViewById(R.id.btnBack);

        upload = findViewById(R.id.btnUpload);
        select = findViewById(R.id.btnSelect);
        imageView = findViewById(R.id.img);

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Storage di firebase
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        // Terminazione dell'activity
        back.setOnClickListener(view -> {
            Intent intent = new Intent(gesture_addProdotto.this, gesture.class);
            startActivity(intent);
            finish();
        });

        // per selezionare l'immagine
        select.setOnClickListener(v -> SelectImage());

        // cofermare e caricare il nuovo prodotto
        upload.setOnClickListener(v -> {
            String nome_ = Objects.requireNonNull(nome.getText()).toString();
            String descrizione_ = descrizione.getText().toString();
            String prezzo_ = prezzo.getText().toString();
            String valutazione_ = valutazione.getText().toString();
            //utilizzato per selezionare il nome dell'immagine correttamente
            String path = filePath.getPath();
            int index = path.lastIndexOf('/');
            String name = path.substring(index);
            path = "/ImmaginiProdotti" + name;
            //Creazione dell'item con i valori impostati dall'admin
            Items item = new Items(nome_, descrizione_, prezzo_, valutazione_, path);
            db.collection("Prodotti").document(nome_)
                    .set(item)
                    .addOnSuccessListener(aVoid -> System.out.println("ok"))
                    .addOnFailureListener(e -> System.out.println("ok"));
            //una volta ultimato il caricamento l'activity restarta
            finish();
            startActivity(getIntent());
        });
    }


    // Metodo per la selezione dell'immagine
    private void SelectImage() {

        // Si imposta l'intent sulla cartella immagini del telefono
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Seleziona l'immagine"), PICK_IMAGE_REQUEST);
    }

    // Override metodo onActivityResult
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // checking request code and result code
        // if request code is PICK_IMAGE_REQUEST and
        // resultCode is RESULT_OK
        // then set image in the image view

        // si controlla il requestiCode e il resulCode
        // se requestCode è uguale a PICK_IMAGE_REQUEST e resultCode è uguale a RESULT_OK
        // si può settare l'immagine
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

            // si ottiene il path
            filePath = data.getData();
            try {
                // si setta l'immagine con il metodo della bitmap
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                //in caso di eccezioni si stampano
                e.printStackTrace();
            }
        }
    }
}