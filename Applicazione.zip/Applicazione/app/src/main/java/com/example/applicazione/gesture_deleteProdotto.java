package com.example.applicazione;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class gesture_deleteProdotto extends AppCompatActivity {

    Button back, update;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    List<Items> list = new LinkedList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gesture_delete_prodotto);
        back = findViewById(R.id.btnBackD);
        update = findViewById(R.id.btnUpdateD);
        back.setOnClickListener(view -> {
            Intent intent = new Intent(gesture_deleteProdotto.this, gesture.class);
            startActivity(intent);
            finish();
        });

        // premendo il tasto update l'activity viene ricaricata
        update.setOnClickListener(view -> {
            finish();
            startActivity(getIntent());
        });

        scaricoItem(list);
    }

    public void scaricoItem(List<Items> list){
        // Si accede alla collezione Prodotti, ottenendo tute le raccolte
        db.collection("Prodotti")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            HashMap<String, Object> info = (HashMap<String, Object>) document.getData();
                            // si estrapolano le informazioni inerenti all'oggetto e si creano l'item
                            Items item = new Items((String)info.get("nome"), (String)info.get("descrizione"),(String)info.get("prezzo"), String.valueOf(info.get("valutazione")),(String) info.get("path"));
                            // l'item verrà aggiunto alla lista
                            list.add(item);
                        }
                        // una volta ottenuata la lista completa con tutti gli item, si richiama l'adapter
                        setAdapter(list);
                    } else {
                        System.out.println("Error getting documents: " + task.getException());
                    }
                });
    }

    public void setAdapter(List<Items> list){
        ListView listView = findViewById(R.id.item_list3);
        CustomAdapterDeleteItem adapter = new CustomAdapterDeleteItem(this, R.layout.activity_righe_lista, list);
        listView.setAdapter(adapter);
    }

}
