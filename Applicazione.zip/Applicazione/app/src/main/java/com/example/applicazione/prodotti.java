package com.example.applicazione;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Switch;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class prodotti extends AppCompatActivity {

    static int chiamante;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prodotti);

        List<Items> list = new LinkedList<>();

        back = findViewById(R.id.btnBack2);
        back.setOnClickListener(view -> {
            // Se il chiamante è un admin viene reindirizzato nell'home admin, altrimenti se è un
            // basic user nell'home normale
            if (chiamante == 0){
                Intent intent = new Intent(prodotti.this, AdminHome.class);
                finish();
                startActivity(intent);
            }else {
                Intent intent = new Intent(prodotti.this, home.class);
                finish();
                startActivity(intent);
            }
        });
        //Funzoione che serve per scaricare la lista degli item e richiamare l'adapter
        scaricoItem(list);
    }

    public void scaricoItem(List<Items> list){
        //si Scaricano tutti i prodotti
        db.collection("Prodotti")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            HashMap<String, Object> info = (HashMap<String, Object>) document.getData();
                            //Si creano i prodotti e si aggiungono ad una lista
                            Items item = new Items((String)info.get("nome"), (String)info.get("descrizione"),(String)info.get("prezzo"), String.valueOf(info.get("valutazione")),(String) info.get("path"));
                            list.add(item);
                        }
                        //si richiama l'adapter
                        setAdapter(list);
                    } else {
                        System.out.println("Error getting documents: " + task.getException());
                    }
                });
        return;
    }

    public void setAdapter(List<Items> list){
        ListView listView = (ListView)findViewById(R.id.item_list2);
        // Si distingue tra chi è l'utente, se un utente base o l'admin
        if(login.getAdmin()){
            // Adapter admin
            CustomAdapterProdottiAdmin adapter = new CustomAdapterProdottiAdmin(this, R.layout.activity_righe_lista, list);
            listView.setAdapter(adapter);
        } else{
            // Adapter Client
            System.out.println("Adapter client");
            CustomAdapterProdotti adapter = new CustomAdapterProdotti(this, R.layout.activity_righe_lista, list);
            listView.setAdapter(adapter);
        }
    }

    //si Setta il chiamante
    public static void setChiamante(int chiamante) {
        prodotti.chiamante = chiamante;
    }
}