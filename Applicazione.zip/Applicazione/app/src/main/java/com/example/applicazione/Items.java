package com.example.applicazione;

import com.google.firebase.firestore.DocumentReference;

import java.util.ArrayList;
import java.util.HashMap;

public class Items {
    String Nome, Descrizione;
    String Prezzo, Valutazione;
    String Path_immagine;

    public Items(String nome, String descrizione, String prezzo, String valutazione, String foto){
        this.Nome = nome;
        this.Descrizione = descrizione;
        this.Prezzo = prezzo;
        this.Valutazione = valutazione;
        this.Path_immagine = foto;
    }

    // metodo utilizzato durante la progettazione dell'applicazione, lo si utilizzava per stampare le informazioni dell'item
    public void print(){
        System.out.println("Nome: "+ Nome + "\n Descrizione: "+ Descrizione + "\n Prezzo: " + Prezzo + "\n Valutazione: "+  Valutazione+ "\n Path Image: " + Path_immagine);
    }

    //Metodi utilizzati dagli Adapter per ottenere le informazioni sugli attributi
    public String getPath(){
        return Path_immagine;
    }

    public String getNome() {
        return Nome;
    }

    public String getDescrizione() {
        return Descrizione;
    }

    public String getPrezzo() {
        return Prezzo;
    }

    public float getValutazione() {
        return Float.parseFloat(Valutazione);
    }

}

